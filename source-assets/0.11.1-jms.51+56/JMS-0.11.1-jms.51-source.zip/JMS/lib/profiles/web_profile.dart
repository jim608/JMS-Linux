import 'package:fladder/jellyfin/jellyfin_open_api.swagger.dart';
import 'package:fladder/util/web_video_capabilities.dart';

const DeviceProfile webProfile = DeviceProfile(
  maxStreamingBitrate: 120000000,
  maxStaticBitrate: 100000000,
  musicStreamingTranscodingBitrate: 384000,
  directPlayProfiles: [
    DirectPlayProfile(
      container: 'mkv,webm',
      type: DlnaProfileType.video,
      videoCodec: 'h264,hevc,vp8,vp9,av1',
      audioCodec: 'vorbis,opus,aac',
    ),
    DirectPlayProfile(
      container: 'mp4,m4v',
      type: DlnaProfileType.video,
      videoCodec: 'h264,hevc,vp8,vp9,av1',
      audioCodec: 'aac,mp3,mp2,opus,flac,vorbis',
    ),
    DirectPlayProfile(
      container: 'mov',
      type: DlnaProfileType.video,
      videoCodec: 'h264',
      audioCodec: 'aac,mp3,mp2,opus,flac,vorbis',
    ),
    DirectPlayProfile(container: 'opus', type: DlnaProfileType.audio),
    DirectPlayProfile(
        container: 'webm', audioCodec: 'opus', type: DlnaProfileType.audio),
    DirectPlayProfile(container: 'mp3', type: DlnaProfileType.audio),
    DirectPlayProfile(container: 'aac', type: DlnaProfileType.audio),
    DirectPlayProfile(
        container: 'm4a', audioCodec: 'aac', type: DlnaProfileType.audio),
    DirectPlayProfile(
        container: 'm4b', audioCodec: 'aac', type: DlnaProfileType.audio),
    DirectPlayProfile(container: 'flac', type: DlnaProfileType.audio),
    DirectPlayProfile(container: 'webma', type: DlnaProfileType.audio),
    DirectPlayProfile(
        container: 'webm', audioCodec: 'webma', type: DlnaProfileType.audio),
    DirectPlayProfile(container: 'wav', type: DlnaProfileType.audio),
    DirectPlayProfile(container: 'ogg', type: DlnaProfileType.audio),
    DirectPlayProfile(
      container: 'hls',
      type: DlnaProfileType.video,
      videoCodec: 'h264',
      audioCodec: 'aac,mp3,mp2',
    ),
  ],
  transcodingProfiles: [
    TranscodingProfile(
      container: 'ts',
      type: DlnaProfileType.audio,
      audioCodec: 'aac',
      context: EncodingContext.streaming,
      protocol: MediaStreamProtocol.hls,
      maxAudioChannels: '2',
      minSegments: 1,
      breakOnNonKeyFrames: true,
    ),
    TranscodingProfile(
      container: 'aac',
      type: DlnaProfileType.audio,
      audioCodec: 'aac',
      context: EncodingContext.streaming,
      protocol: MediaStreamProtocol.http,
      maxAudioChannels: '2',
    ),
    TranscodingProfile(
      container: 'mp3',
      type: DlnaProfileType.audio,
      audioCodec: 'mp3',
      context: EncodingContext.streaming,
      protocol: MediaStreamProtocol.http,
      maxAudioChannels: '2',
    ),
    TranscodingProfile(
      container: 'opus',
      type: DlnaProfileType.audio,
      audioCodec: 'opus',
      context: EncodingContext.streaming,
      protocol: MediaStreamProtocol.http,
      maxAudioChannels: '2',
    ),
    TranscodingProfile(
      container: 'wav',
      type: DlnaProfileType.audio,
      audioCodec: 'wav',
      context: EncodingContext.streaming,
      protocol: MediaStreamProtocol.http,
      maxAudioChannels: '2',
    ),
    TranscodingProfile(
      container: 'opus',
      type: DlnaProfileType.audio,
      audioCodec: 'opus',
      context: EncodingContext.$static,
      protocol: MediaStreamProtocol.http,
      maxAudioChannels: '2',
    ),
    TranscodingProfile(
      container: 'mp3',
      type: DlnaProfileType.audio,
      audioCodec: 'mp3',
      context: EncodingContext.$static,
      protocol: MediaStreamProtocol.http,
      maxAudioChannels: '2',
    ),
    TranscodingProfile(
      container: 'aac',
      type: DlnaProfileType.audio,
      audioCodec: 'aac',
      context: EncodingContext.$static,
      protocol: MediaStreamProtocol.http,
      maxAudioChannels: '2',
    ),
    TranscodingProfile(
      container: 'wav',
      type: DlnaProfileType.audio,
      audioCodec: 'wav',
      context: EncodingContext.$static,
      protocol: MediaStreamProtocol.http,
      maxAudioChannels: '2',
    ),
    TranscodingProfile(
      container: 'ts',
      type: DlnaProfileType.video,
      audioCodec: 'aac,mp3,mp2',
      videoCodec: 'h264',
      context: EncodingContext.streaming,
      protocol: MediaStreamProtocol.hls,
      maxAudioChannels: '2',
      minSegments: 1,
      breakOnNonKeyFrames: true,
    ),
  ],
  containerProfiles: [],
  codecProfiles: [
    CodecProfile(
      type: CodecType.videoaudio,
      codec: 'aac',
      conditions: [
        ProfileCondition(
          condition: ProfileConditionType.equals,
          property: ProfileConditionValue.issecondaryaudio,
          $Value: 'false',
          isRequired: false,
        ),
      ],
    ),
    CodecProfile(
      type: CodecType.videoaudio,
      conditions: [
        ProfileCondition(
          condition: ProfileConditionType.equals,
          property: ProfileConditionValue.issecondaryaudio,
          $Value: 'false',
          isRequired: false,
        ),
      ],
    ),
    CodecProfile(
      type: CodecType.video,
      codec: 'h264',
      conditions: [
        ProfileCondition(
          condition: ProfileConditionType.notequals,
          property: ProfileConditionValue.isanamorphic,
          $Value: 'true',
          isRequired: false,
        ),
        ProfileCondition(
          condition: ProfileConditionType.equalsany,
          property: ProfileConditionValue.videorangetype,
          $Value: webAdvertisedVideoRangeTypes,
          isRequired: false,
        ),
        ProfileCondition(
          condition: ProfileConditionType.lessthanequal,
          property: ProfileConditionValue.videolevel,
          $Value: '52',
          isRequired: false,
        ),
        ProfileCondition(
          condition: ProfileConditionType.notequals,
          property: ProfileConditionValue.isinterlaced,
          $Value: 'true',
          isRequired: false,
        ),
      ],
    ),
    CodecProfile(
      type: CodecType.video,
      codec: 'hevc',
      conditions: [
        ProfileCondition(
          condition: ProfileConditionType.notequals,
          property: ProfileConditionValue.isanamorphic,
          $Value: 'true',
          isRequired: false,
        ),
        ProfileCondition(
          condition: ProfileConditionType.equalsany,
          property: ProfileConditionValue.videoprofile,
          $Value: 'main',
          isRequired: false,
        ),
        ProfileCondition(
          condition: ProfileConditionType.equalsany,
          property: ProfileConditionValue.videorangetype,
          $Value: webAdvertisedVideoRangeTypes,
          isRequired: false,
        ),
        ProfileCondition(
          condition: ProfileConditionType.lessthanequal,
          property: ProfileConditionValue.videolevel,
          $Value: '120',
          isRequired: false,
        ),
        ProfileCondition(
          condition: ProfileConditionType.notequals,
          property: ProfileConditionValue.isinterlaced,
          $Value: 'true',
          isRequired: false,
        ),
      ],
    ),
    CodecProfile(
      type: CodecType.video,
      codec: 'vp9',
      conditions: [
        ProfileCondition(
          condition: ProfileConditionType.equalsany,
          property: ProfileConditionValue.videorangetype,
          $Value: webAdvertisedVideoRangeTypes,
          isRequired: false,
        ),
      ],
    ),
    CodecProfile(
      type: CodecType.video,
      codec: 'av1',
      conditions: [
        ProfileCondition(
          condition: ProfileConditionType.notequals,
          property: ProfileConditionValue.isanamorphic,
          $Value: 'true',
          isRequired: false,
        ),
        ProfileCondition(
          condition: ProfileConditionType.equalsany,
          property: ProfileConditionValue.videoprofile,
          $Value: 'main',
          isRequired: false,
        ),
        ProfileCondition(
          condition: ProfileConditionType.equalsany,
          property: ProfileConditionValue.videorangetype,
          $Value: webAdvertisedVideoRangeTypes,
          isRequired: false,
        ),
        ProfileCondition(
          condition: ProfileConditionType.lessthanequal,
          property: ProfileConditionValue.videolevel,
          $Value: '19',
          isRequired: false,
        ),
      ],
    ),
  ],
  subtitleProfiles: [
    SubtitleProfile(format: 'vtt', method: SubtitleDeliveryMethod.embed),
    SubtitleProfile(format: 'srt', method: SubtitleDeliveryMethod.embed),
  ],
);
