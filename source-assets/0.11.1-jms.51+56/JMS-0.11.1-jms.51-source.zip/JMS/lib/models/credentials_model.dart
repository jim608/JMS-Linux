import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:xid/xid.dart';

import 'package:fladder/providers/arguments_provider.dart';
import 'package:fladder/util/application_info.dart';
import 'package:fladder/util/string_extensions.dart';

part 'credentials_model.freezed.dart';
part 'credentials_model.g.dart';

@Freezed(copyWith: true)
abstract class CredentialsModel with _$CredentialsModel {
  const CredentialsModel._();

  factory CredentialsModel.internal({
    @Default("") String token,
    @Default("") String url,
    // Retained only to read existing accounts; automatic local URL routing was removed.
    String? localUrl,
    @Default("") String serverName,
    @Default("") String serverId,
    @Default("") String deviceId,
  }) = _CredentialsModel;

  factory CredentialsModel.createNewCredentials() =>
      CredentialsModel.internal(deviceId: Xid().toString());

  Map<String, String> header(Ref ref,
      {String? deviceIdOverride, bool includeClient = true}) {
    final application = ref.read(applicationInfoProvider);
    final leanbackMode = ref.read(argumentsStateProvider).leanBackMode;
    final os = switch (application.platform) {
      TargetPlatform.android => kIsWeb
          ? "${application.platform.name.capitalize()} Web"
          : (leanbackMode
              ? "${application.platform.name.capitalize()} TV"
              : application.platform.name.capitalize()),
      _ => !kIsWeb
          ? application.platform.name.capitalize()
          : "${application.platform.name.capitalize()} Web",
    };
    final client = includeClient ? ', Client="${application.name}"' : '';
    final headers = {
      'authorization':
          'MediaBrowser Token="$token"$client, Device="$os", DeviceId="${deviceIdOverride ?? deviceId}", Version="${application.version}"'
    };
    return headers;
  }

  factory CredentialsModel.fromJson(Map<String, dynamic> json) =>
      _$CredentialsModelFromJson(json);

  factory CredentialsModel.fromJsonString(String source) =>
      CredentialsModel.fromMap(json.decode(source));

  factory CredentialsModel.fromMap(Map<String, dynamic> map) {
    return CredentialsModel.internal(
      token: map['token'] ?? '',
      url: map['server'] ?? '',
      serverName: map['serverName'] ?? '',
      serverId: map['serverId'] ?? '',
      deviceId: map['deviceId'] ?? '',
    );
  }
}
