import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

import 'package:freezed_annotation/freezed_annotation.dart';

import 'package:fladder/models/items/media_segments_model.dart';
import 'package:fladder/models/settings/arguments_model.dart';
import 'package:fladder/models/settings/key_combinations.dart';
import 'package:fladder/util/bitrate_helper.dart';
import 'package:fladder/util/ambient_interval.dart';
import 'package:fladder/util/localization_helper.dart';

part 'video_player_settings.freezed.dart';
part 'video_player_settings.g.dart';

enum VideoHotKeys {
  playPause,
  seekForward,
  seekBack,
  seekForwardInstant,
  seekBackInstant,
  stepForward,
  stepBack,
  mute,
  volumeUp,
  volumeDown,
  speedUp,
  speedDown,
  nextVideo,
  prevVideo,
  nextChapter,
  prevChapter,
  fullScreen,
  skipMediaSegment,
  takeScreenshot,
  takeScreenshotClean,
  toggleSubtitles,
  exit;

  const VideoHotKeys();

  String label(BuildContext context) {
    return switch (this) {
      VideoHotKeys.playPause => context.localized.playPause,
      VideoHotKeys.seekForward => context.localized.seekForward,
      VideoHotKeys.seekBack => context.localized.seekBack,
      VideoHotKeys.seekForwardInstant => context.localized.seekForwardInstant,
      VideoHotKeys.seekBackInstant => context.localized.seekBackInstant,
      VideoHotKeys.stepForward => context.localized.stepForward,
      VideoHotKeys.stepBack => context.localized.stepBack,
      VideoHotKeys.mute => context.localized.mute,
      VideoHotKeys.volumeUp => context.localized.volumeUp,
      VideoHotKeys.volumeDown => context.localized.volumeDown,
      VideoHotKeys.speedUp => context.localized.speedUp,
      VideoHotKeys.speedDown => context.localized.speedDown,
      VideoHotKeys.nextVideo => context.localized.nextVideo,
      VideoHotKeys.prevVideo => context.localized.prevVideo,
      VideoHotKeys.nextChapter => context.localized.nextChapter,
      VideoHotKeys.prevChapter => context.localized.prevChapter,
      VideoHotKeys.fullScreen => context.localized.fullScreen,
      VideoHotKeys.skipMediaSegment => context.localized.skipMediaSegment,
      VideoHotKeys.takeScreenshot => context.localized.takeScreenshot,
      VideoHotKeys.takeScreenshotClean => context.localized.takeScreenshotClean,
      VideoHotKeys.toggleSubtitles => context.localized.toggleSubtitles,
      VideoHotKeys.exit => context.localized.exit,
    };
  }
}

@Freezed(copyWith: true)
abstract class VideoPlayerSettingsModel with _$VideoPlayerSettingsModel {
  const VideoPlayerSettingsModel._();

  static bool get crossfadeSupportedOnCurrentPlatform {
    if (kIsWeb) return true;
    return switch (defaultTargetPlatform) {
      TargetPlatform.android || TargetPlatform.iOS => false,
      _ => true,
    };
  }

  factory VideoPlayerSettingsModel({
    double? screenBrightness,
    @Default(BoxFit.contain) BoxFit videoFit,
    @Default(false) bool fillScreen,
    @Default(true) bool hardwareAccel,
    @Default(true) bool useLibass,
    @Default(false) bool enableTunneling,
    @Default(32) int bufferSize,
    PlayerOptions? playerOptions,
    @Default(100) double internalVolume,
    Set<DeviceOrientation>? allowedOrientations,
    @Default(AutoNextType.smart) AutoNextType nextVideoType,
    @Default(Bitrate.original) Bitrate maxHomeBitrate,
    @Default(Bitrate.original) Bitrate maxInternetBitrate,
    String? audioDevice,
    @Default(defaultSegmentSkipValues) Map<MediaSegmentType, SegmentSkip> segmentSkipSettings,
    @Default({}) Map<VideoHotKeys, KeyCombination> hotKeys,
    @Default(Screensaver.logo) Screensaver screensaver,
    @Default(false) bool enableSpeedBoost,
    @Default(2.0) double speedBoostRate,
    @Default(true) bool enableDoubleTapSeek,
    @Default(false) bool enableAdvancedVideoOptions,
    @Default(true) bool enableEdgeGestures,
    @Default(false) bool reverseEdgeGestures,
    @Default(true) bool enablePictureInPicture,
    @Default(true) bool enableReplayGain,
    @Default(ReplayGainVolumeLevel.quiet) ReplayGainVolumeLevel replayGainVolumeLevel,
    @Default(true) bool enablePlayPauseFade,
    @Default(true) bool enableCrossfade,
    @Default(400) int crossfadeDurationMs,
    @Default(false) bool ambientBlur,
    @Default(0.8) double ambientIntensity,
    @Default(0.9) double ambientSpread,
    @Default(4.0) double ambientIntervalSeconds,
    @Default(false) bool ambientSyncToPlayback,
  }) = _VideoPlayerSettingsModel;

  double get volume {
    if ({TargetPlatform.android, TargetPlatform.iOS}.contains(defaultTargetPlatform)) {
      return 100;
    }
    return internalVolume;
  }

  factory VideoPlayerSettingsModel.fromJson(Map<String, dynamic> json) => _$VideoPlayerSettingsModelFromJson(json);

  double get effectiveAmbientIntensity => ambientIntensity.isFinite ? ambientIntensity.clamp(0.0, 1.0) : 0.8;
  double get effectiveAmbientSpread => ambientSpread.isFinite ? ambientSpread.clamp(0.0, 1.0) : 0.9;
  double get effectiveAmbientIntervalSeconds => boundedAmbientIntervalSeconds(ambientIntervalSeconds);

  bool get androidMdkUnavailable =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.android && playerOptions == PlayerOptions.libMDK;

  bool get windowsMdkUnavailable =>
      !kIsWeb &&
      {TargetPlatform.windows, TargetPlatform.linux}.contains(defaultTargetPlatform) &&
      playerOptions == PlayerOptions.libMDK;

  PlayerOptions get wantedPlayer {
    // Restored settings may refer to a backend unavailable on this platform.
    // Resolve at runtime without replacing the user's stored preference.
    if (kIsWeb) return PlayerOptions.libMPV;
    if ({TargetPlatform.windows, TargetPlatform.linux}.contains(defaultTargetPlatform) &&
        (leanBackMode || playerOptions == PlayerOptions.nativePlayer)) {
      return PlayerOptions.libMPV;
    }
    if (leanBackMode) return PlayerOptions.nativePlayer;
    if (androidMdkUnavailable || windowsMdkUnavailable) return PlayerOptions.libMPV;
    return playerOptions ?? PlayerOptions.platformDefaults;
  }

  Map<VideoHotKeys, KeyCombination> get currentShortcuts =>
      _defaultVideoHotKeys.map((key, value) => MapEntry(key, hotKeys[key] ?? value));

  Map<VideoHotKeys, KeyCombination> get defaultShortCuts => _defaultVideoHotKeys;

  bool get canUseCrossfade => crossfadeSupportedOnCurrentPlatform;

  bool playerSame(VideoPlayerSettingsModel other) {
    return other.hardwareAccel == hardwareAccel &&
        other.enableTunneling == enableTunneling &&
        other.useLibass == useLibass &&
        other.bufferSize == bufferSize &&
        other.wantedPlayer == wantedPlayer;
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is VideoPlayerSettingsModel &&
        other.screenBrightness == screenBrightness &&
        other.videoFit == videoFit &&
        other.fillScreen == fillScreen &&
        other.hardwareAccel == hardwareAccel &&
        other.useLibass == useLibass &&
        other.enableTunneling == enableTunneling &&
        other.bufferSize == bufferSize &&
        other.internalVolume == internalVolume &&
        other.playerOptions == playerOptions &&
        other.audioDevice == audioDevice;
  }

  @override
  int get hashCode {
    return screenBrightness.hashCode ^
        videoFit.hashCode ^
        fillScreen.hashCode ^
        hardwareAccel.hashCode ^
        useLibass.hashCode ^
        enableTunneling.hashCode ^
        bufferSize.hashCode ^
        internalVolume.hashCode ^
        audioDevice.hashCode;
  }
}

enum PlayerOptions {
  libMDK,
  libMPV,
  nativePlayer;

  const PlayerOptions();

  static Iterable<PlayerOptions> get available => leanBackMode
      ? {PlayerOptions.nativePlayer}
      : kIsWeb
          ? {PlayerOptions.libMPV}
          : switch (defaultTargetPlatform) {
              TargetPlatform.android => {PlayerOptions.libMPV, PlayerOptions.nativePlayer},
              TargetPlatform.windows || TargetPlatform.linux => {PlayerOptions.libMPV},
              _ => {PlayerOptions.libMDK, PlayerOptions.libMPV},
            };

  static PlayerOptions get platformDefaults {
    if (leanBackMode) return PlayerOptions.nativePlayer;
    if (kIsWeb) return PlayerOptions.libMPV;
    return switch (defaultTargetPlatform) {
      _ => PlayerOptions.libMPV,
    };
  }

  String label(BuildContext context) => switch (this) {
        PlayerOptions.libMDK => "MDK",
        PlayerOptions.libMPV => "MPV",
        PlayerOptions.nativePlayer => "Native",
      };
}

double clampReplayGainDb(double gainDb) {
  return gainDb.clamp(-60.0, 0.0).toDouble();
}

enum ReplayGainVolumeLevel {
  // Keep enum ids stable for persisted settings; labels are user-facing.
  quiet,
  normal,
  loud;

  const ReplayGainVolumeLevel();

  String label(BuildContext context) => switch (this) {
        ReplayGainVolumeLevel.quiet => context.localized.quiet,
        ReplayGainVolumeLevel.normal => context.localized.normal,
        ReplayGainVolumeLevel.loud => context.localized.loud,
      };

  double get replayGainOffsetDb => switch (this) {
        ReplayGainVolumeLevel.quiet => 0.0,
        ReplayGainVolumeLevel.normal => 6.0,
        ReplayGainVolumeLevel.loud => 8.0,
      };

  double adjustedReplayGainDb(double? trackGainDb) {
    return clampReplayGainDb((trackGainDb ?? 0) + replayGainOffsetDb);
  }
}

enum Screensaver {
  disabled,
  dvd,
  logo,
  time,
  black;

  const Screensaver();

  String label(BuildContext context) => switch (this) {
        Screensaver.disabled => context.localized.disabled,
        Screensaver.dvd => context.localized.screensaverDvd,
        Screensaver.logo => context.localized.screensaverLogo,
        Screensaver.time => context.localized.screensaverTime,
        Screensaver.black => context.localized.screensaverBlack,
      };
}

enum AutoNextType {
  off,
  smart,
  static;

  const AutoNextType();

  String label(BuildContext context) => switch (this) {
        AutoNextType.off => context.localized.off,
        AutoNextType.smart => context.localized.autoNextOffSmartTitle,
        AutoNextType.static => context.localized.autoNextOffStaticTitle,
      };

  String desc(BuildContext context) => switch (this) {
        AutoNextType.off => context.localized.off,
        AutoNextType.smart => context.localized.autoNextOffSmartDesc,
        AutoNextType.static => context.localized.autoNextOffStaticDesc,
      };
}

Map<VideoHotKeys, KeyCombination> get _defaultVideoHotKeys => {
      for (var hotKey in VideoHotKeys.values)
        hotKey: switch (hotKey) {
          VideoHotKeys.playPause => KeyCombination(
              key: LogicalKeyboardKey.space,
              altKey: LogicalKeyboardKey.keyK,
            ),
          VideoHotKeys.seekForward => KeyCombination(
              key: LogicalKeyboardKey.arrowRight,
              altKey: LogicalKeyboardKey.keyL,
            ),
          VideoHotKeys.seekBack => KeyCombination(
              key: LogicalKeyboardKey.arrowLeft,
              altKey: LogicalKeyboardKey.keyJ,
            ),
          VideoHotKeys.seekForwardInstant => KeyCombination(
              key: LogicalKeyboardKey.arrowRight,
              modifier: LogicalKeyboardKey.shiftLeft,
              altKey: LogicalKeyboardKey.keyL,
              altModifier: LogicalKeyboardKey.shiftLeft,
            ),
          VideoHotKeys.seekBackInstant => KeyCombination(
              key: LogicalKeyboardKey.arrowLeft,
              modifier: LogicalKeyboardKey.shiftLeft,
              altKey: LogicalKeyboardKey.keyJ,
              altModifier: LogicalKeyboardKey.shiftLeft,
            ),
          VideoHotKeys.stepForward => KeyCombination(key: LogicalKeyboardKey.period),
          VideoHotKeys.stepBack => KeyCombination(key: LogicalKeyboardKey.comma),
          VideoHotKeys.mute => KeyCombination(key: LogicalKeyboardKey.keyM),
          VideoHotKeys.volumeUp => KeyCombination(key: LogicalKeyboardKey.arrowUp),
          VideoHotKeys.volumeDown => KeyCombination(key: LogicalKeyboardKey.arrowDown),
          VideoHotKeys.speedUp =>
            KeyCombination(key: LogicalKeyboardKey.arrowUp, modifier: LogicalKeyboardKey.controlLeft),
          VideoHotKeys.speedDown =>
            KeyCombination(key: LogicalKeyboardKey.arrowDown, modifier: LogicalKeyboardKey.controlLeft),
          VideoHotKeys.prevVideo =>
            KeyCombination(key: LogicalKeyboardKey.keyP, modifier: LogicalKeyboardKey.shiftLeft),
          VideoHotKeys.nextVideo =>
            KeyCombination(key: LogicalKeyboardKey.keyN, modifier: LogicalKeyboardKey.shiftLeft),
          VideoHotKeys.nextChapter => KeyCombination(key: LogicalKeyboardKey.pageUp),
          VideoHotKeys.prevChapter => KeyCombination(key: LogicalKeyboardKey.pageDown),
          VideoHotKeys.fullScreen => KeyCombination(key: LogicalKeyboardKey.keyF),
          VideoHotKeys.skipMediaSegment => KeyCombination(key: LogicalKeyboardKey.keyS),
          VideoHotKeys.takeScreenshot => KeyCombination(key: LogicalKeyboardKey.keyG),
          VideoHotKeys.takeScreenshotClean =>
            KeyCombination(key: LogicalKeyboardKey.keyG, modifier: LogicalKeyboardKey.controlLeft),
          VideoHotKeys.toggleSubtitles => KeyCombination(key: LogicalKeyboardKey.keyT),
          VideoHotKeys.exit => KeyCombination(key: LogicalKeyboardKey.escape),
        },
    };
