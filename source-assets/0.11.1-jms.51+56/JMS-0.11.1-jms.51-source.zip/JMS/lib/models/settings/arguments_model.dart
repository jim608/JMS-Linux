import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:fladder/util/jms_test_profile_policy.dart';

part 'arguments_model.freezed.dart';

/// Prefer using the arguments provider over this boolean
bool leanBackMode = false;

class NotificationKeys {
  static const String skipNotifications = '--skipNotifications';
  static const String newWindow = '--newWindow';
  static const String htpcMode = '--htpc';
  static const String handheldMode = '--handheld';
}

@Freezed(copyWith: true)
abstract class ArgumentsModel with _$ArgumentsModel {
  const ArgumentsModel._();

  factory ArgumentsModel({
    @Default(false) bool htpcMode,
    @Default(false) bool handheldMode,
    @Default(false) bool leanBackMode,
    @Default(false) bool newWindow,
    @Default(false) bool skipNotifications,
  }) = _ArgumentsModel;

  factory ArgumentsModel.fromArguments(
      List<String> arguments, String windowArguments, bool leanBackEnabled) {
    arguments = arguments.map((e) => e.trim()).toList();
    leanBackMode = leanBackEnabled;
    final parsedWindowArgs = windowArguments.split(',');
    final shouldSkipNotifications = JmsTestProfilePolicy.enabled ||
        arguments.contains(NotificationKeys.skipNotifications) ||
        parsedWindowArgs.contains(NotificationKeys.skipNotifications) ||
        parsedWindowArgs.contains(NotificationKeys.newWindow);
    return ArgumentsModel(
      htpcMode:
          arguments.contains(NotificationKeys.htpcMode) || leanBackEnabled,
      handheldMode: arguments.contains(NotificationKeys.handheldMode) ||
          parsedWindowArgs.contains(NotificationKeys.handheldMode),
      leanBackMode: leanBackEnabled,
      newWindow: parsedWindowArgs.contains(NotificationKeys.newWindow),
      skipNotifications: shouldSkipNotifications,
    );
  }
}
