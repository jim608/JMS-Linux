import 'dart:async';
import 'dart:math';

import 'package:flutter/widgets.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:fladder/jellyfin/jellyfin_open_api.enums.swagger.dart';
import 'package:fladder/models/account_model.dart';
import 'package:fladder/models/settings/video_player_settings.dart';
import 'package:fladder/profiles/default_profile.dart';
import 'package:fladder/models/playback/offline_playback_model.dart';
import 'package:fladder/models/playback/tv_playback_model.dart';
import 'package:fladder/providers/api_provider.dart';
import 'package:fladder/providers/connectivity_provider.dart' as connectivity;
import 'package:fladder/providers/user_provider.dart';
import 'package:fladder/providers/video_player_provider.dart';
import 'package:fladder/services/syncplay/syncplay_controller.dart';
import 'package:fladder/services/syncplay/syncplay_buffering.dart';
import 'package:fladder/services/syncplay/syncplay_models.dart';
import 'package:fladder/services/syncplay/syncplay_player.dart';
import 'package:fladder/services/syncplay/syncplay_player_commands.dart';
import 'package:fladder/services/syncplay/syncplay_prebuffer.dart';
import 'package:fladder/services/syncplay/syncplay_prebuffer_coordinator.dart';
import 'package:fladder/services/syncplay/syncplay_transport.dart';
import 'package:fladder/services/syncplay/syncplay_recovery.dart';
import 'package:fladder/wrappers/media_control_wrapper.dart';
import 'package:fladder/util/application_info.dart';

final syncPlayProvider =
    StateNotifierProvider<SyncPlayNotifier, SyncPlayViewState>((ref) {
  return SyncPlayNotifier(ref);
});

class SyncPlayViewState {
  const SyncPlayViewState({
    this.room = const SyncPlayControllerState(connected: false),
    this.busy = false,
    this.failure,
    this.preparingPlayback = false,
    this.readyHomeJoin,
    this.prebuffer,
    this.recoveryActive = false,
    this.recoveryExhausted = false,
    this.leavePending = false,
  });
  final SyncPlayControllerState room;
  final bool busy;
  final SyncPlayFailure? failure;
  final bool preparingPlayback;
  final int? readyHomeJoin;
  final SyncPlayPrebufferDecision? prebuffer;
  final bool recoveryActive;
  final bool recoveryExhausted;
  final bool leavePending;
}

class _CreatorPlaybackIntent {
  _CreatorPlaybackIntent(this.operation, this.paused);
  final int operation;
  bool paused;
  bool explicit = false;
}

/// Explicitly opened by the room dialog. No socket, room, or sharing at startup.
/// Every asynchronous operation remains bound to the captured login generation.
class SyncPlayNotifier extends StateNotifier<SyncPlayViewState>
    implements SyncPlayPlayerCommands {
  SyncPlayNotifier(this.ref) : super(const SyncPlayViewState()) {
    _accountSubscription = ref.listen(userProvider, (previous, next) {
      if (!_sameLogin(previous, next)) {
        _backgroundLeaveResult = null;
        _permissionOperation++;
        _permissionChecking = false;
        _permissionFailed = false;
      }
      if (!_sameLogin(previous, next) ||
          previous?.policy?.syncPlayAccess != next?.policy?.syncPlayAccess) {
        _detach();
      }
    });
  }

  final Ref ref;
  ProviderSubscription<AccountModel?>? _accountSubscription;
  ProviderSubscription<connectivity.ConnectionState>? _connectivitySubscription;
  AppLifecycleListener? _lifecycle;
  SyncPlayRecovery? _recovery;
  SyncPlayTransport? _transport;
  SyncPlayController? _controller;
  SyncPlayPlayerAdapter? _player;
  StreamSubscription<SyncPlayControllerState>? _stateSubscription;
  StreamSubscription<bool>? _connectionSubscription;
  StreamSubscription? _playerSubscription;
  int _generation = 0;
  int _uiOperation = 0;
  MediaControlsWrapper? _wrapper;
  bool _disposed = false;
  SyncPlayBufferingReporter? _bufferingReporter;
  SyncPlayPrebufferCoordinator? _prebuffer;
  static const _prebufferConfig = SyncPlayPrebufferConfig();
  int _permissionOperation = 0;
  bool _permissionChecking = false;
  bool _permissionFailed = false;
  int _homeSerial = 0;
  int? _homeJoinAttempt;
  int? _readyHomeJoin;
  bool _homeMode = false;
  bool _preparingPlayback = false;
  bool _localLeaveIntent = false;
  _CreatorPlaybackIntent? _creatorPlaybackIntent;
  Future<void>? _leaveSettlement;
  SyncPlayControllerState? _backgroundLeaveResult;

  /// Last remote cleanup result, retained for diagnostics only. Local playback
  /// and normal room UI never wait for this result or present it as a workflow.
  SyncPlayControllerState? get backgroundLeaveResult => _backgroundLeaveResult;

  SyncPlayViewState _view(
          {SyncPlayControllerState? room,
          bool busy = false,
          SyncPlayFailure? failure}) =>
      SyncPlayViewState(
          room: _localLeaveIntent
              ? const SyncPlayControllerState(connected: false)
              : room ?? state.room,
          busy: !_localLeaveIntent && busy,
          failure: _localLeaveIntent ? null : failure,
          preparingPlayback: _preparingPlayback,
          readyHomeJoin: _readyHomeJoin,
          prebuffer: _prebuffer?.decision,
          recoveryActive: _recovery?.active ?? false,
          recoveryExhausted: _recovery?.exhausted ?? false,
          leavePending: _localLeaveIntent && _controller != null);

  /// Home joining is independent of the currently selected media/backend.
  /// The captured room item is authorized before preparing a built-in player.
  bool get canJoinFromHome {
    final account = ref.read(userProvider);
    return canJoin &&
        account != null &&
        account.credentials.token.isNotEmpty &&
        account.credentials.deviceId.isNotEmpty;
  }

  int? beginHomeJoin(String code) {
    if (_disposed ||
        state.busy ||
        _preparingPlayback ||
        !canJoinFromHome ||
        state.room.status != SyncPlayStatus.idle) {
      return null;
    }
    final ticket = ++_homeSerial;
    _homeJoinAttempt = ticket;
    _readyHomeJoin = null;
    _homeMode = true;
    _preparingPlayback = true;
    unawaited(joinRoom(code));
    return ticket;
  }

  Future<void> cancelHomeJoin(int ticket) async {
    if (_disposed || ticket != _homeJoinAttempt) return;
    _homeJoinAttempt = null;
    _readyHomeJoin = null;
    _preparingPlayback = false;
    await stop();
  }

  int? beginHomeReconnect() {
    if (_disposed ||
        _localLeaveIntent ||
        (_controller?.leaveRequested ?? false) ||
        state.busy ||
        !canJoinFromHome ||
        !const {SyncPlayStatus.unknown, SyncPlayStatus.disconnected}
            .contains(state.room.status)) {
      return null;
    }
    final ticket = ++_homeSerial;
    _homeJoinAttempt = ticket;
    _readyHomeJoin = null;
    _homeMode = true;
    _preparingPlayback = true;
    unawaited(reconnect());
    return ticket;
  }

  bool consumeHomeJoin(int ticket) {
    if (_disposed ||
        ticket != _homeJoinAttempt ||
        ticket != _readyHomeJoin ||
        !state.room.isJoined ||
        state.room.failure != null ||
        _player?.playlistItemId != state.room.queue?.current?.playlistItemId ||
        _player?.mediaId != state.room.queue?.current?.mediaId) {
      return false;
    }
    _homeJoinAttempt = null;
    _readyHomeJoin = null;
    state = _view(room: state.room, busy: state.busy, failure: state.failure);
    return true;
  }

  static bool _sameLogin(AccountModel? a, AccountModel? b) =>
      a?.id == b?.id && a?.credentials == b?.credentials;

  bool get permissionChecking => _permissionChecking;
  bool get permissionKnown =>
      !_permissionChecking &&
      !_permissionFailed &&
      ref.read(userProvider)?.policy?.syncPlayAccess != null;

  bool get canJoin =>
      permissionKnown &&
      switch (ref.read(userProvider)?.policy?.syncPlayAccess) {
        SyncPlayUserAccessType.createandjoingroups ||
        SyncPlayUserAccessType.joingroups =>
          true,
        _ => false,
      };
  bool get canCreate =>
      permissionKnown &&
      ref.read(userProvider)?.policy?.syncPlayAccess ==
          SyncPlayUserAccessType.createandjoingroups;

  /// Explicit dialog-open refresh; opening the panel never creates a socket.
  Future<void> refreshPermission() async {
    if (_disposed || _permissionChecking) return;
    final account = ref.read(userProvider);
    if (account == null) return;
    final operation = ++_permissionOperation;
    bool current() =>
        !_disposed &&
        operation == _permissionOperation &&
        _sameLogin(account, ref.read(userProvider));
    _permissionChecking = true;
    _permissionFailed = false;
    void notify() {
      state = _view(room: state.room, busy: state.busy, failure: state.failure);
    }

    notify();
    void Function()? closeApi;
    try {
      final api = createJellyfinApiForAccount(ref, account.credentials.url,
          Map<String, String>.unmodifiable(account.credentials.header(ref)),
          privateLink: true);
      closeApi = () {
        try {
          api.client.httpClient.close();
        } catch (_) {}
        try {
          api.client.dispose();
        } catch (_) {}
      };
      final response =
          await api.usersMeGet().timeout(const Duration(seconds: 10));
      if (!current()) return;
      final user = response.body;
      if (!response.isSuccessful ||
          user?.id != account.id ||
          user?.policy == null) {
        _permissionFailed = true;
        return;
      }
      ref
          .read(userProvider.notifier)
          .updateRuntimePolicyForAccount(account, user!.policy!);
    } catch (_) {
      if (current()) _permissionFailed = true;
    } finally {
      closeApi?.call();
      if (current()) {
        _permissionChecking = false;
        notify();
      }
    }
  }

  bool get supported {
    final model = ref.read(playBackModel);
    final player = ref.read(videoPlayerProvider);
    return model != null &&
        model is! OfflinePlaybackModel &&
        model is! TvPlaybackModel &&
        !model.isAudioPlayback &&
        player.supportsSyncPlay;
  }

  @override
  bool get active =>
      !_disposed &&
      _controller != null &&
      !_localLeaveIntent &&
      !_controller!.leaveRequested &&
      (state.busy ||
          !const {SyncPlayStatus.idle, SyncPlayStatus.disposed}
              .contains(_controller!.state.status));

  Future<bool> _ensureSession() async {
    if (_disposed || !(_homeMode ? canJoinFromHome : supported && canJoin)) {
      return false;
    }
    if (_controller == null ||
        (_controller!.state.status == SyncPlayStatus.idle &&
            !_controller!.leaveRequested)) {
      _localLeaveIntent = false;
    }
    if (_transport != null) return _transport!.connected;
    final account = ref.read(userProvider);
    if (account == null ||
        account.credentials.token.isEmpty ||
        account.credentials.deviceId.isEmpty) {
      return false;
    }
    final generation = ++_generation;
    bool current() =>
        !_disposed &&
        generation == _generation &&
        _sameLogin(account, ref.read(userProvider));
    final playbackHeaders =
        Map<String, String>.unmodifiable(account.credentials.header(ref));
    final isolateControlSession = !kIsWeb &&
        ref.read(applicationInfoProvider).platform == TargetPlatform.windows;
    var controlHeaders = playbackHeaders;
    var controlDeviceId = account.credentials.deviceId;
    if (isolateControlSession) {
      final random = Random.secure();
      final nonce = List.generate(
              16, (_) => random.nextInt(256).toRadixString(16).padLeft(2, '0'))
          .join();
      // Older room sockets resolve Client from the authentication token and
      // DeviceId from the query. Omit Client on control REST too, so both paths
      // share that token client and one fresh control-only DeviceId. An old
      // Leave cannot address a replacement room or the saved playback session.
      controlDeviceId = 'jms-syncplay-$nonce';
      controlHeaders = Map<String, String>.unmodifiable(account.credentials
          .header(ref,
              deviceIdOverride: controlDeviceId, includeClient: false));
    }
    final api = createJellyfinApiForAccount(
        ref, account.credentials.url, controlHeaders,
        privateLink: true);
    SyncPlayTransport? constructedTransport;
    try {
      final transport = SyncPlayTransport(
        api: api,
        baseUri: Uri.parse(account.credentials.url),
        token: account.credentials.token,
        deviceId: controlDeviceId,
        socketHeaders: isolateControlSession ? controlHeaders : null,
        traceRestHeaders: isolateControlSession ? controlHeaders : null,
        isCurrent: current,
      );
      constructedTransport = transport;
      _transport = transport;
      final player = SyncPlayPlayerAdapter(
        ref: ref,
        account: account,
        api: api,
        isCurrent: () => current() && !_localLeaveIntent,
        queue: () => current() ? _controller?.state.queue : null,
        createPlaybackApi: () => createJellyfinApiForAccount(
            ref, account.credentials.url, playbackHeaders,
            privateLink: true),
        isPlaybackIdentityCurrent: () =>
            !_disposed && _sameLogin(account, ref.read(userProvider)),
        playbackPrepared: () => !_homeMode || _wrapper != null,
        playbackProfile:
            _homeMode ? defaultProfile(PlayerOptions.libMPV) : null,
        prepareForPlayback: _homeMode
            ? () async {
                if (_wrapper != null) return current();
                final ticket = _homeJoinAttempt;
                bool preparingCurrent() =>
                    current() && ticket != null && ticket == _homeJoinAttempt;
                if (!preparingCurrent()) return false;
                final ready = await ref
                    .read(videoPlayerProvider.notifier)
                    .prepareSyncPlayPlayback(isCurrent: preparingCurrent);
                if (!ready || !preparingCurrent()) {
                  return false;
                }
                _bindPlayer(
                    controller: _controller!,
                    player: _player!,
                    current: current);
                return true;
              }
            : null,
        onLoaded: () {
          if (!current() || _homeJoinAttempt == null) return;
          _preparingPlayback = false;
          _readyHomeJoin = _homeJoinAttempt;
          state = _view(room: _controller!.state, busy: state.busy);
        },
      );
      _player = player;
      final controller = SyncPlayController(
        identity: SyncPlayIdentity(
            sourceId: account.credentials.url,
            userId: account.id,
            sessionId: '${account.credentials.deviceId}:$generation'),
        api: transport,
        player: player,
        events: transport.events,
        isPlayerBuffering: () => player.isBuffering,
        mediaReadiness: () => _prebuffer?.ready ?? false,
        bufferedAhead: () => _prebuffer?.ahead,
        targetBufferedAhead: () => _prebuffer?.target,
        slowWaitBudget: _prebufferConfig.maximumWait,
        cancelPendingPlayerActions: player.cancelPendingActions,
      );
      _controller = controller;
      controller.setConnected(false);
      _recovery = SyncPlayRecovery(
        readState: () => controller.state,
        isCurrent: () => current() && !controller.initialQueueUncertain,
        reconnectTransport: transport.reconnect,
        rejoinKnownGroup: (isRecoveryCurrent) => controller.reconnect(
            automatic: true, isRecoveryCurrent: isRecoveryCurrent),
        revalidate: () async {
          await controller.refreshMembership();
          if (current() && controller.state.isJoined) {
            await controller.synchronizeClock();
          }
        },
        onChanged: () {
          if (current()) {
            state = _view(room: controller.state, busy: state.busy);
          }
        },
      );
      _lifecycle = AppLifecycleListener(onResume: () => _recovery?.wake());
      _connectivitySubscription = ref.listen(
        connectivity.connectivityStatusProvider,
        (previous, next) {
          if (current() &&
              previous == connectivity.ConnectionState.offline &&
              next != connectivity.ConnectionState.offline) {
            _recovery?.wake();
          }
        },
      );
      _stateSubscription = controller.states.listen((room) {
        if (current()) {
          if (_localLeaveIntent &&
              !controller.leaveRequested &&
              room.status == SyncPlayStatus.idle) {
            _backgroundLeaveResult = room;
            state = _view(room: room);
            // The controller stream is synchronous; disposal emits its final
            // state, so release it after this notification has unwound.
            scheduleMicrotask(() {
              if (current() &&
                  _localLeaveIntent &&
                  !controller.leaveRequested &&
                  controller.state.status == SyncPlayStatus.idle) {
                _detach();
              }
            });
            return;
          }
          _bufferingReporter?.refreshQueue();
          _prebuffer?.refresh();
          if (_homeJoinAttempt != null &&
              state.room.queue?.current?.playlistItemId !=
                  room.queue?.current?.playlistItemId) {
            _readyHomeJoin = null;
            _preparingPlayback = true;
          }
          if (!room.isJoined &&
              const {
                SyncPlayStatus.idle,
                SyncPlayStatus.unknown,
                SyncPlayStatus.disconnected
              }.contains(room.status)) {
            _readyHomeJoin = null;
            if (state.room.group != null) _preparingPlayback = false;
          }
          if (room.failure != null) _preparingPlayback = false;
          if (controller.initialQueueUncertain) _recovery?.cancel();
          state = _view(room: room, busy: state.busy);
          if (!controller.initialQueueUncertain) _recovery?.observe(room);
        }
      });
      _connectionSubscription = transport.connections.listen((connected) {
        if (current()) controller.setConnected(connected);
      });
      if (!_homeMode) {
        _bindPlayer(controller: controller, player: player, current: current);
      }
      await transport.connect();
      if (!current()) return false;
      controller.setConnected(transport.connected);
      return transport.connected;
    } catch (_) {
      if (constructedTransport == null) {
        try {
          api.client.httpClient.close();
        } catch (_) {}
        try {
          api.client.dispose();
        } catch (_) {}
      } else if (!current()) {
        await constructedTransport.close();
      }
      if (current()) {
        _detach();
        state = const SyncPlayViewState(
            failure: SyncPlayFailure(SyncPlayFailureCode.disconnected));
      }
      return false;
    }
  }

  void _bindPlayer(
      {required SyncPlayController controller,
      required SyncPlayPlayerAdapter player,
      required bool Function() current}) {
    if (_wrapper != null) return;
    final wrapper = ref.read(videoPlayerProvider);
    _wrapper = wrapper;
    wrapper.syncPlayCommands = this;
    final bufferingReporter = SyncPlayBufferingReporter(
      isCurrent: current,
      isBuffering: () => player.isBuffering,
      queueKey: () {
        final room = controller.state;
        final entry = room.queue?.current;
        return room.isJoined && room.connected && entry != null
            ? (room.group!.groupId, entry.playlistItemId)
            : null;
      },
      report: (buffering) => unawaited(controller.reportBuffering(buffering)),
    );
    _bufferingReporter = bufferingReporter;
    final prebuffer = SyncPlayPrebufferCoordinator(
      isCurrent: () => current() && identical(_wrapper, wrapper),
      isActive: () {
        final room = controller.state;
        final entry = room.queue?.current;
        return room.isJoined &&
            room.connected &&
            !controller.isLoading &&
            room.failure?.code != SyncPlayFailureCode.player &&
            entry != null &&
            player.mediaId == entry.mediaId &&
            player.playlistItemId == entry.playlistItemId;
      },
      generation: () => (controller.mediaBufferEpoch, wrapper),
      readSample: wrapper.readSyncPlayBufferSample,
      verifiedForwardBudget: wrapper.configureSyncPlayBufferBudget,
      config: _prebufferConfig,
      onDecision: (_) {
        if (current() && identical(_wrapper, wrapper)) {
          unawaited(controller.notifyMediaReadinessChanged());
        }
      },
    );
    _prebuffer = prebuffer;
    prebuffer.refresh();
    _playerSubscription = wrapper.stateStream.listen((snapshot) {
      if (!current() || !controller.state.isJoined) {
        return;
      }
      bufferingReporter.update(snapshot.buffering);
      prebuffer.refresh();
    });
  }

  Future<void> _run(Future<void> Function() operation) async {
    if (_disposed || state.busy) return;
    final operationId = ++_uiOperation;
    state = _view(room: state.room, busy: true);
    try {
      await operation();
    } catch (_) {
      if (!_disposed && operationId == _uiOperation) {
        state = _view(
            room: state.room,
            failure: const SyncPlayFailure(SyncPlayFailureCode.server));
      }
    } finally {
      if (!_disposed && operationId == _uiOperation) {
        state = _view(room: state.room, failure: state.failure);
      }
    }
  }

  Future<void> createRoom() => _run(() async {
        if (!canCreate || !supported) return;
        final operationId = _uiOperation;
        final itemId = ref.read(playBackModel)?.item.id;
        final initialPlayer = ref.read(videoPlayerProvider).lastState;
        final position = initialPlayer?.position ?? Duration.zero;
        final startPaused = initialPlayer?.playing == false;
        final preserveIntent = !kIsWeb &&
            ref.read(applicationInfoProvider).platform ==
                TargetPlatform.windows;
        final intent = _CreatorPlaybackIntent(operationId, startPaused);
        if (preserveIntent) _creatorPlaybackIntent = intent;
        try {
          if (itemId == null || !await _ensureSession()) return;
          if (_localLeaveIntent || operationId != _uiOperation) return;
          if (!intent.explicit) {
            // Until New, a local control may have changed the original player
            // before the room wrapper was bound. No room load has paused it yet.
            intent.paused =
                ref.read(videoPlayerProvider).lastState?.playing == false;
          }
          final controller = _controller!;
          final generation = _generation;
          final code = (100000 + Random.secure().nextInt(900000)).toString();
          await controller.createRoom(code,
              startPaused: preserveIntent ? intent.paused : null);
          if (_disposed ||
              _localLeaveIntent ||
              operationId != _uiOperation ||
              generation != _generation ||
              !controller.state.isJoined) {
            return;
          }
          await controller.synchronizeClock();
          if (_disposed ||
              _localLeaveIntent ||
              operationId != _uiOperation ||
              generation != _generation) {
            return;
          }
          await controller.setQueue([itemId],
              position: position, startPaused: preserveIntent && intent.paused);
        } finally {
          if (identical(intent, _creatorPlaybackIntent)) {
            _creatorPlaybackIntent = null;
          }
        }
      });

  Future<void> joinRoom(String code) => _run(() async {
        final operationId = _uiOperation;
        if (!canJoin || !(_homeMode || supported) || !await _ensureSession()) {
          return;
        }
        if (_localLeaveIntent || operationId != _uiOperation) return;
        await _controller!.joinRoom(code);
      });

  /// Return solo control immediately. Server settlement has its own bounded
  /// lifetime and must never keep the dialog or local player waiting.
  Future<void> leaveRoom() async {
    if (_disposed) return;
    _releaseLocalSync();
    final controller = _controller;
    if (controller == null) {
      _detach();
      return;
    }
    unawaited(_settleLeave(controller));
  }

  Future<void> _settleLeave(SyncPlayController controller) {
    final existing = _leaveSettlement;
    if (existing != null) return existing;
    late final Future<void> task;
    task = () async {
      try {
        await controller.leaveRoom();
        if (_disposed || !identical(controller, _controller)) return;
        _backgroundLeaveResult = controller.state;
      } catch (_) {
        if (!_disposed && identical(controller, _controller)) {
          _backgroundLeaveResult = const SyncPlayControllerState(
            status: SyncPlayStatus.unknown,
            failure: SyncPlayFailure(SyncPlayFailureCode.server),
            connected: false,
          );
        }
      } finally {
        // End the old session after this one bounded attempt, including an
        // unknown remote result. No retry panel, socket recovery, or stale
        // callback may keep owning the player's solo controls afterward.
        if (!_disposed && identical(controller, _controller)) {
          _detach();
        }
        if (identical(task, _leaveSettlement)) _leaveSettlement = null;
      }
    }();
    _leaveSettlement = task;
    return task;
  }

  void _releaseLocalSync() {
    _localLeaveIntent = true;
    _backgroundLeaveResult = null;
    ++_uiOperation; // Revoke New/Join continuations even while they are busy.
    _homeJoinAttempt = null;
    _readyHomeJoin = null;
    _preparingPlayback = false;
    _recovery?.cancel();
    _player?.cancelPendingActions();
    _bufferingReporter?.dispose();
    _bufferingReporter = null;
    _prebuffer?.dispose();
    _prebuffer = null;
    unawaited(_playerSubscription?.cancel());
    _playerSubscription = null;
    final wrapper = _wrapper;
    _wrapper = null;
    if (wrapper != null && identical(wrapper.syncPlayCommands, this)) {
      wrapper.syncPlayCommands = null;
    }
    // Do not seek, reload, pause or play: preserve the current solo position
    // and pause state, including a Pause pressed while room loading was busy.
    state = _view(room: _controller?.state);
  }

  Future<void> reconnect() => _run(() async {
        final transport = _transport;
        final controller = _controller;
        if (transport == null || controller == null) return;
        if (controller.leaveRequested || _localLeaveIntent) {
          _recovery?.cancel();
          // Leave uses authenticated HTTP and does not require reconnecting the
          // room socket. A dead socket must not add another confirmation hoop.
          if (!identical(controller, _controller)) return;
          await _settleLeave(controller);
          return;
        }
        if (controller.initialQueueUncertain) return;
        if (!(_homeMode || supported) || !canJoin) return;
        _recovery?.manualRetry();
        await transport.reconnect();
        await controller.reconnect();
      });

  @override
  Future<void> pause() async {
    final intent = _creatorPlaybackIntent;
    if (intent != null && intent.operation == _uiOperation) {
      intent.paused = true;
      intent.explicit = true;
    }
    await _controller?.requestPause(userInitiated: true);
  }

  @override
  Future<void> play() async {
    final intent = _creatorPlaybackIntent;
    if (intent != null && intent.operation == _uiOperation) {
      intent.paused = false;
      intent.explicit = true;
    }
    await _controller?.requestUnpause(userInitiated: true);
  }

  @override
  Future<void> seek(Duration position) async {
    await _controller?.requestSeek(position, userInitiated: true);
  }

  @override
  Future<void> stop() async {
    await leaveRoom();
  }

  void _detach() {
    _localLeaveIntent = false;
    _recovery?.dispose();
    _recovery = null;
    _lifecycle?.dispose();
    _lifecycle = null;
    _connectivitySubscription?.close();
    _connectivitySubscription = null;
    _homeJoinAttempt = null;
    _readyHomeJoin = null;
    _homeMode = false;
    _preparingPlayback = false;
    ++_generation; // Revoke stale callbacks before the first asynchronous cleanup.
    _player?.cancelPendingActions();
    _player = null;
    ++_uiOperation;
    final controller = _controller;
    final transport = _transport;
    _controller = null;
    _leaveSettlement = null;
    _transport = null;
    _bufferingReporter?.dispose();
    _bufferingReporter = null;
    _prebuffer?.dispose();
    _prebuffer = null;
    unawaited(_stateSubscription?.cancel());
    unawaited(_connectionSubscription?.cancel());
    unawaited(_playerSubscription?.cancel());
    _stateSubscription = null;
    _connectionSubscription = null;
    _playerSubscription = null;
    final wrapper = _wrapper;
    _wrapper = null;
    if (wrapper != null && identical(wrapper.syncPlayCommands, this)) {
      wrapper.syncPlayCommands = null;
    }
    unawaited(controller?.dispose());
    unawaited(transport?.close());
    if (!_disposed) state = const SyncPlayViewState();
  }

  @override
  void dispose() {
    _disposed = true;
    _accountSubscription?.close();
    _detach();
    super.dispose();
  }
}
