import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:chopper/chopper.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:punycoder/punycoder.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:fladder/jellyfin/jellyfin_open_api.swagger.dart';
import 'package:fladder/providers/auth_provider.dart';
import 'package:fladder/providers/connectivity_provider.dart';
import 'package:fladder/providers/service_provider.dart';
import 'package:fladder/providers/user_provider.dart';
import 'package:fladder/util/seerr_http_client.dart'
    if (dart.library.html) 'package:fladder/util/seerr_http_client_web.dart';
part 'api_provider.g.dart';

final serverUrlProvider = StateProvider<String?>((ref) {
  final userCredentials = ref.watch(userProvider.select((value) => value?.credentials));
  final tempUrl = ref.watch(authProvider.select((value) => value.serverLoginModel?.tempCredentials.url));
  String? newUrl;

  if (userCredentials?.url.isNotEmpty == true) {
    newUrl = userCredentials?.url;
  } else if (tempUrl?.isNotEmpty == true) {
    newUrl = tempUrl;
  } else {
    newUrl = null;
  }

  return normalizeUrl(newUrl ?? "");
});

@riverpod
class JellyApi extends _$JellyApi {
  @override
  JellyService build() => JellyService(
        ref,
        JellyfinOpenApi.create(
          interceptors: [
            JellyRequest(ref),
            JellyResponse(ref),
            HttpLoggingInterceptor(level: Level.basic),
          ],
        ),
      );
}

JellyfinOpenApi createJellyfinApiForAccount(Ref ref, String baseUrl, Map<String, String> headers,
    {bool privateLink = false}) {
  return JellyfinOpenApi.create(
    httpClient: privateLink ? createJellyfinHttpClient() : null,
    interceptors: [
      _TempJellyRequest(baseUrl: baseUrl, headers: headers),
      if (!privateLink) JellyResponse(ref),
      if (!privateLink) HttpLoggingInterceptor(level: Level.basic),
    ],
  );
}

class _TempJellyRequest implements Interceptor {
  _TempJellyRequest({required this.baseUrl, required this.headers});

  final String baseUrl;
  final Map<String, String> headers;

  @override
  FutureOr<Response<BodyType>> intercept<BodyType>(Chain<BodyType> chain) async {
    if (baseUrl.isEmpty) throw const HttpException('No server URL provided for temp request');

    final request = applyHeaders(chain.request.copyWith(baseUri: Uri.parse(baseUrl)), headers);
    return chain.proceed(request);
  }
}

final int _maxRetries = 3;

bool _isConnectionError(Object e) {
  return e is IOException || e is TimeoutException;
}

class JellyRequest implements Interceptor {
  JellyRequest(this.ref);

  final Ref ref;

  @override
  FutureOr<Response<BodyType>> intercept<BodyType>(Chain<BodyType> chain) async {
    final connectivityNotifier = ref.read(connectivityStatusProvider.notifier);
    await connectivityNotifier.waitForProbe();
    final serverUrl = ref.read(serverUrlProvider);

    if (serverUrl == null || serverUrl.isEmpty) {
      throw const HttpException('No server URL provided');
    }

    // Use current logged in user otherwise use the authProvider
    final loginModel = ref.read(userProvider)?.credentials ?? ref.read(authProvider).serverLoginModel?.tempCredentials;
    if (loginModel == null) {
      throw UnimplementedError();
    }

    final headers = loginModel.header(ref);

    for (var attempt = 0; attempt <= _maxRetries; attempt++) {
      try {
        final response = await chain.proceed(
          applyHeaders(
            chain.request.copyWith(baseUri: Uri.parse(serverUrl)),
            headers,
          ),
        );
        unawaited(connectivityNotifier.checkConnectivity(immediate: true));
        return response;
      } catch (e) {
        if (!_isConnectionError(e) || attempt == _maxRetries) {
          unawaited(connectivityNotifier.checkConnectivity(immediate: true));
          rethrow;
        }

        final delay = Duration(milliseconds: 200 * (attempt + 1));
        log('Connection failed (attempt ${attempt + 1}/$_maxRetries), retrying in ${delay.inMilliseconds}ms: $e');
        await Future.delayed(delay);
      }
    }
    throw StateError('Unexpected state in JellyRequest.intercept');
  }
}

/// Whether [url] already carries an http or https scheme.
/// Uses toLowerCase() because users may type mixed-case schemes (e.g. Https://, HTTP://).
bool hasHttpScheme(String url) {
  final lower = url.toLowerCase();
  return lower.startsWith('http://') || lower.startsWith('https://');
}

String normalizeUrl(String url) {
  final trimmed = url.trim();
  if (trimmed.isEmpty) return '';

  final withScheme = hasHttpScheme(trimmed) ? trimmed : 'http://$trimmed';
  final parsed = Uri.parse(withScheme);

  // Only punycode non-ASCII hostnames. IP addresses are always ASCII, so no special handling needed.
  final host = parsed.host;
  final hasNonAscii = host.runes.any((c) => c > 0x7F);

  if (!hasNonAscii) return parsed.toString();

  try {
    final encodedHost = const PunycodeCodec().encode(host);
    return parsed.replace(host: encodedHost).toString();
  } catch (_) {
    return parsed.toString();
  }
}

Future<String?> _probeUrl(String baseUrl, String endpoint) async {
  try {
    await http.head(Uri.parse('$baseUrl$endpoint')).timeout(const Duration(seconds: 5));
    // Any HTTP response (including 4xx/5xx) means the server is reachable at this URL.
    // This only acts as scheme detection, not as health check.
    return baseUrl;
  } catch (e) {
    log('Probe failed for $baseUrl$endpoint: $e');
  }
  return null;
}

/// Probes a Seerr server URL by hitting /api/v1/status.
Future<String?> probeSeerrUrl(String baseUrl) => _probeUrl(baseUrl, '/api/v1/status');

/// Probes a Jellyfin server URL by hitting /System/Info/Public.
Future<String?> probeJellyfinUrl(String baseUrl) => _probeUrl(baseUrl, '/System/Info/Public');

/// Result of [probeAndNormalizeUrl]: the resolved URL and whether a probe succeeded.
typedef ProbeResult = ({String url, bool probed});

/// Tries https and http in parallel using [probeFn] if no scheme is provided.
/// Always returns a usable URL (falls back to https when both probes fail).
/// If a scheme is already present, returns the normalized URL without probing.
Future<ProbeResult> probeAndNormalizeUrl(String url, Future<String?> Function(String) probeFn) async {
  if (!hasHttpScheme(url)) {
    final httpsUrl = normalizeUrl('https://$url');
    final httpUrl = normalizeUrl('http://$url');
    final httpFuture = probeFn(httpUrl);
    final httpsResult = await probeFn(httpsUrl);
    if (httpsResult != null) return (url: httpsResult, probed: true);
    final httpResult = await httpFuture;
    return (url: httpResult ?? httpsUrl, probed: httpResult != null);
  }
  return (url: normalizeUrl(url), probed: true);
}

Uri? tryParseServerBaseUri(String? url) {
  if (url == null) return null;
  final trimmed = url.trim();
  if (trimmed.isEmpty) return null;

  final parsed = Uri.tryParse(trimmed);
  if (parsed == null || parsed.scheme.isEmpty || parsed.host.isEmpty) return null;
  return parsed;
}

Uri? serverBaseUri(Ref ref) => tryParseServerBaseUri(ref.read(serverUrlProvider));

Uri? buildServerUriFromBase(
  String baseUrl, {
  List<String> pathSegments = const [],
  String? relativeUrl,
  Map<String, String?>? queryParameters,
}) {
  final base = tryParseServerBaseUri(baseUrl);
  if (base == null) return null;

  Uri? relative;
  if (relativeUrl != null && relativeUrl.trim().isNotEmpty) {
    relative = Uri.tryParse(relativeUrl.trim());
  }

  if (relative?.hasScheme == true && relative?.host.isNotEmpty == true) {
    return relative;
  }

  final baseSegments = base.pathSegments.where((s) => s.isNotEmpty).toList(growable: false);
  final relSegments = (relative?.pathSegments ?? const <String>[]).where((s) => s.isNotEmpty).toList(growable: false);
  final extraSegments = pathSegments.where((s) => s.isNotEmpty).toList(growable: false);

  final mergedSegments = <String>[...baseSegments, ...relSegments, ...extraSegments];

  final mergedQuery = <String, String>{...?(relative?.queryParameters)};
  if (queryParameters != null) {
    for (final entry in queryParameters.entries) {
      final value = entry.value;
      if (value == null) continue;
      mergedQuery[entry.key] = value;
    }
  }

  return Uri(
    scheme: base.scheme,
    userInfo: base.userInfo,
    host: base.host,
    port: base.hasPort ? base.port : null,
    pathSegments: mergedSegments,
    queryParameters: mergedQuery.isNotEmpty ? mergedQuery : null,
    fragment: relative?.hasFragment == true ? relative!.fragment : null,
  );
}

Uri? buildServerUri(
  Ref ref, {
  List<String> pathSegments = const [],
  String? relativeUrl,
  Map<String, String?>? queryParameters,
}) {
  final baseUrl = ref.read(serverUrlProvider);
  if (baseUrl == null || baseUrl.isEmpty) return null;
  return buildServerUriFromBase(
    baseUrl,
    pathSegments: pathSegments,
    relativeUrl: relativeUrl,
    queryParameters: queryParameters,
  );
}

String buildServerUrl(
  Ref ref, {
  List<String> pathSegments = const [],
  String? relativeUrl,
  Map<String, String?>? queryParameters,
}) {
  return buildServerUri(
        ref,
        pathSegments: pathSegments,
        relativeUrl: relativeUrl,
        queryParameters: queryParameters,
      )?.toString() ??
      '';
}

class JellyResponse implements Interceptor {
  JellyResponse(this.ref);

  final Ref ref;

  @override
  FutureOr<Response<BodyType>> intercept<BodyType>(Chain<BodyType> chain) async {
    final Response<BodyType> response = await chain.proceed(chain.request);

    if (!response.isSuccessful) {
      log('x- ${response.base.statusCode} - ${response.base.reasonPhrase} - ${response.error} - ${response.base.request?.method} ${response.base.request?.url.toString()}');
    }
    if (response.statusCode == 404) {
      chopperLogger.severe('404 NOT FOUND');
    }

    return response;
  }
}
