// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'library_screen_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$libraryScreenHash() => r'5d8081eb06237faff36a459850b5076039c40b30';

/// See also [LibraryScreen].
@ProviderFor(LibraryScreen)
final libraryScreenProvider =
    NotifierProvider<LibraryScreen, LibraryScreenModel>.internal(
  LibraryScreen.new,
  name: r'libraryScreenProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$libraryScreenHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$LibraryScreen = Notifier<LibraryScreenModel>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
